import socket
import threading
import ssl
from database import check_user, add_user

SERVER_IP = '192.168.56.101'
SERVER_PORT = 6666

def broadcast(message, sender_socket):
    for client in clients:
        if client != sender_socket:
            try:
                client.send(message)
            except:
                client.close()
                remove_client(client)

def remove_client(client_socket):
    if client_socket in clients:
        clients.remove(client_socket)

def handle_client(client_socket):
    while True:
        try:
            credentials = client_socket.recv(1024).decode('utf-8')
            username, password, register = credentials.split(';')
            if register == 'yes':
                if not check_user(username, password):
                    add_user(username, password)
                    client_socket.send("Registered".encode('utf-8'))
                else:
                    client_socket.send("Already Exists".encode('utf-8'))
            elif check_user(username, password):
                client_socket.send("Login Success".encode('utf-8'))
                break
            else:
                client_socket.send("Login Failed".encode('utf-8'))
        except:
            remove_client(client_socket)
            break
    while True:
        message = client_socket.recv(1024)
        if message:
            broadcast(message, client_socket)
        else:
            remove_client(client_socket)
            break

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((SERVER_IP, SERVER_PORT))
    server_socket.listen(5)
    print(f"Server listening on {SERVER_IP}:{SERVER_PORT}")

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile="./certificate.pem", keyfile="./private_key.pem")

    while True:
        client_socket, addr = server_socket.accept()
        secure_socket = context.wrap_socket(client_socket, server_side=True)
        clients.append(secure_socket)
        print(f"Connection from {addr}")

        client_handler = threading.Thread(target=handle_client, args=(secure_socket,))
        client_handler.start()

if __name__ == "__main__":
    clients = []
    start_server()
