from PIL import Image, ImageTk  # Import necessary libraries from PIL
import tkinter as tk
import socket
import ssl
import threading
from tkinter import messagebox

SERVER_IP = '192.168.56.101'
SERVER_PORT = 6666

def receive_messages(secure_socket, chat_box):
    while True:
        try:
            message = secure_socket.recv(1024).decode('utf-8')
            if message:
                chat_box.insert(tk.END, message + "\n")
        except Exception as e:
            print(f"Error receiving message: {e}")
            break

def send_message(entry_widget, secure_socket, username, chat_box):
    message = entry_widget.get()
    if message:
        try:
            formatted_message = f"{username}: {message}"
            secure_socket.send(formatted_message.encode('utf-8'))
            chat_box.insert(tk.END, formatted_message + "\n")
        except Exception as e:
            print(f"Error sending message: {e}")
        finally:
            entry_widget.delete(0, tk.END)

def setup_connection(username, password, register):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    context.load_verify_locations("./certificate.pem")
    secure_socket = context.wrap_socket(client_socket, server_hostname=SERVER_IP)
    secure_socket.connect((SERVER_IP, SERVER_PORT))
    secure_socket.send(f"{username};{password};{register}".encode('utf-8'))
    response = secure_socket.recv(1024).decode('utf-8')
    return secure_socket, response

def start_client():
    root = tk.Tk()
    root.title("Chat Application")
    root.configure(bg='black')

    login_frame = tk.Frame(root, bg='black')
    login_frame.pack(pady=20)

    # Username and Password Entries and Labels
    username_label = tk.Label(login_frame, text="Username", bg='black', fg='white')
    username_label.pack()
    username_entry = tk.Entry(login_frame, bg='gray')
    username_entry.pack(fill=tk.X)

    password_label = tk.Label(login_frame, text="Password", bg='black', fg='white')
    password_label.pack()
    password_entry = tk.Entry(login_frame, show='*', bg='gray')
    password_entry.pack(fill=tk.X)

    # Button Frame for Login and Register
    button_frame = tk.Frame(root, bg='black')
    button_frame.pack(pady=(5, 20))
    login_button = tk.Button(button_frame, text="Login", command=lambda: attempt_login(username_entry.get(), password_entry.get(), "no"))
    login_button.pack(side=tk.LEFT, padx=10)
    register_button = tk.Button(button_frame, text="Register", command=lambda: attempt_login(username_entry.get(), password_entry.get(), "yes"))
    register_button.pack(side=tk.LEFT, padx=10)

    # Image Frame
    image_frame = tk.Frame(root, bg='black')
    
    # Load and display the image
    image = Image.open("./img.jpg")  # Adjust the path to your image file
    image = image.resize((147, 88))  # Resize as per your previous requirement
    photo = ImageTk.PhotoImage(image)
    image_label = tk.Label(image_frame, image=photo, bg='black')

    # Chat Frame
    chat_frame = tk.Frame(root, bg='black')
    chat_box = tk.Text(chat_frame, height=15, width=50, bg='gray', fg='white')
    chat_box.pack(side=tk.TOP, pady=10)

    # Frame for Message Entry and Send Button
    message_frame = tk.Frame(chat_frame, bg='black')
    message_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=5)
    message_entry = tk.Entry(message_frame, bg='gray')
    message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
    send_button = tk.Button(message_frame, text="Send", command=lambda: send_message(message_entry, secure_socket, username_entry.get(), chat_box))
    send_button.pack(side=tk.RIGHT)

    def attempt_login(username, password, register):
        global secure_socket
        secure_socket, response = setup_connection(username, password, register)
        if "Success" in response or "Registered" in response:
            username_label.pack_forget()
            username_entry.pack_forget()
            password_label.pack_forget()
            password_entry.pack_forget()
            button_frame.pack_forget()  # Hide Login and Register buttons
            
            # Reposition the image
            image_frame.pack(pady=(0, 20))  # Adjust vertical padding as needed
            image_label.pack()
            chat_frame.pack(pady=(0, 20))  # Adjust further padding if necessary

            receive_thread = threading.Thread(target=receive_messages, args=(secure_socket, chat_box))
            receive_thread.start()
        else:
            messagebox.showerror("Login Failed", response)

    root.mainloop()

if __name__ == "__main__":
    start_client()

